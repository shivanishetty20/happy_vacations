package com.tcs.admin.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.tcs.admin.model.Admin;

public interface AdminService {
	List<Admin> getAllTrips();
	void saveTrip(Admin admin);
	Admin getTripById(long id);
	void deleteTripById(long id);
	Page<Admin> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);	
}
