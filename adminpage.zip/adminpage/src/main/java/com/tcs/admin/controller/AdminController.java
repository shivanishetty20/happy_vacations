package com.tcs.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tcs.admin.model.Admin;
import com.tcs.admin.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	// display list of trips
	@GetMapping("/")
	public String viewHomePage(Model model) {
		return findPaginated(1, "location", "asc", model);		
	}
	
	
	@GetMapping("/showNewTripForm")
	public String showNewTripForm(Model model) {
		// create model attribute to bind form data
		Admin admin = new Admin();
		model.addAttribute("trip", admin);
		return "new_trip";
	}
	
	@PostMapping("/saveTrip")
	public String saveTrip(@ModelAttribute("trip") Admin admin) {
		// save trip to database
		adminService.saveTrip(admin);
		return "redirect:/";
	}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		
		// get trip from the service
		Admin admin = adminService.getTripById(id);
		
		// set trip as a model attribute to pre-populate the form
		model.addAttribute("trip", admin);
		return "update_trip";
	}
	
	@GetMapping("/deleteTrip/{id}")
	public String deleteTrip(@PathVariable (value = "id") long id) {
		
		// call delete trip method 
		this.adminService.deleteTripById(id);
		return "redirect:/";
	}
	
	
	@GetMapping("/page/{pageNo}")
	public String findPaginated(@PathVariable (value = "pageNo") int pageNo, 
			@RequestParam("sortField") String sortField,
			@RequestParam("sortDir") String sortDir,
			Model model) {
		int pageSize = 5;
		
		Page<Admin> page = adminService.findPaginated(pageNo, pageSize, sortField, sortDir);
		List<Admin> listTrips = page.getContent();
		
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
		
		model.addAttribute("listTrips", listTrips);
		return "index";
	}
	
	@GetMapping("/logout")
	public String logout() {
		return "redirect:http://localhost:8080/logout"; 
	}

}
