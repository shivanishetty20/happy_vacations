package com.tcs.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.user.model.Userpage;

@Repository
public interface UserpageRepository extends JpaRepository<Userpage, Long>{

}
