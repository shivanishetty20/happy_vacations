package com.tcs.user.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.tcs.user.model.Userpage;

public interface UserpageService {
	List<Userpage> getAllTrips();
	Userpage getTripById(long id);
	Page<Userpage> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
	boolean processPayment(String cardNumber, String expirationDate, String cvv, double amount);
	
}
