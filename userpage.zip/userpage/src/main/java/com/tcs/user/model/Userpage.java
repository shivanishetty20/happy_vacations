package com.tcs.user.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "trip_details")
public class Userpage {
	
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "location")
	private String location;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "duration")
	private String duration;
	
	@Column(name = "accommodation_fee")
	private int accommodationFee;
	
	@Column(name = "food_fee")
	private int foodFee;
	
	@Column(name = "travel_fee")
	private int travelFee;

	@Column(name = "guide_fee")
	private int guideFee;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getAccommodationFee() {
		return accommodationFee;
	}

	public void setAccommodationFee(int accommodationFee) {
		this.accommodationFee = accommodationFee;
	}

	public int getFoodFee() {
		return foodFee;
	}

	public void setFoodFee(int foodFee) {
		this.foodFee = foodFee;
	}

	public int getTravelFee() {
		return travelFee;
	}

	public void setTravelFee(int travelFee) {
		this.travelFee = travelFee;
	}

	public int getGuideFee() {
		return guideFee;
	}

	public void setGuideFee(int guideFee) {
		this.guideFee = guideFee;
	}

}
