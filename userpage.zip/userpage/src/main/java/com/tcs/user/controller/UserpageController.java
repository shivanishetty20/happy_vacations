package com.tcs.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tcs.user.model.Userpage;
import com.tcs.user.repository.UserpageRepository;
import com.tcs.user.service.UserpageService;

@Controller
public class UserpageController {

	@Autowired
	private UserpageService userpageService;
	
	@Autowired
	private UserpageRepository userpageRepository;
	
	// display list of trips
	@GetMapping("/")
	public String viewHomePage(Model model) {
		return findPaginated(1, "location", "asc", model);		
	}

	@GetMapping("/showBudget/{id}")
	public String showBudget(@PathVariable ( value = "id") long id, Model model) {
		
		// get trip from the service
		Userpage userpage = userpageService.getTripById(id);
		
		
		  // set trip as a model attribute to pre-populate the form
		  model.addAttribute("trip", userpage);
		 
		return "trip_budget";
	}

	@GetMapping("/calculateTotalCost")
	public String calculateTotalCost(@RequestParam("id") Long id, @RequestParam("numPersons") int numPersons, Model model) {
	    // Retrieve the trip from the database by its ID
	    Userpage trip = userpageRepository.findById(id).orElse(new Userpage());

	    // Add the trip object to the model
	    model.addAttribute("trip", trip);

	    // Calculate the total cost
	    double totalCost = ((trip.getFoodFee() + trip.getAccommodationFee() + trip.getTravelFee()) * numPersons) + trip.getGuideFee();

	    // Add the totalCost attribute to the model
	    model.addAttribute("totalCost", totalCost);

	    // Return the name of the HTML template where you want to display the result
	    return "trip_budget"; // Replace "trip_budget" with the actual name of your template
	}


	@GetMapping("/page/{pageNo}")
	public String findPaginated(@PathVariable (value = "pageNo") int pageNo, 
			@RequestParam("sortField") String sortField,
			@RequestParam("sortDir") String sortDir,
			Model model) {
		int pageSize = 5;
		
		Page<Userpage> page = userpageService.findPaginated(pageNo, pageSize, sortField, sortDir);
		List<Userpage> listTrips = page.getContent();
		
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
		
		model.addAttribute("listTrips", listTrips);
		return "index";
	}
	
    @GetMapping("/payment")
    public String showPaymentPage() {
        return "payment"; 
    }

    @PostMapping("/processPayment")
    public String processPayment(@RequestParam("cardNumber") String cardNumber,
                                 @RequestParam("expirationDate") String expirationDate,
                                 @RequestParam("cvv") String cvv,
                                 @RequestParam("amount") double amount) {
        // Process the payment using the PaymentService
        boolean paymentSuccessful = userpageService.processPayment(cardNumber, expirationDate, cvv, amount);

        if (paymentSuccessful) {
            return "success"; // Return a success page
        } else {
            return "error"; // Return an error page
        }
    }
	
	@GetMapping("/logout")
	public String logout() {
		return "redirect:http://localhost:8080/logout"; 
	}
}
