package com.tcs.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.tcs.user.model.Userpage;
import com.tcs.user.repository.UserpageRepository;

@Service
public class UserpageServiceImpl implements UserpageService {

	@Autowired
	private UserpageRepository userpageRepository;

	@Override
	public List<Userpage> getAllTrips() {
		return userpageRepository.findAll();
	}
	
	@Override
	public Userpage getTripById(long id) {
		Optional<Userpage> optional = userpageRepository.findById(id);
		Userpage userpage = null;
		if (optional.isPresent()) {
			userpage = optional.get();
		} else {
			throw new RuntimeException(" Trip not found for id :: " + id);
		}
		return userpage;
	}
	

	@Override
	public Page<Userpage> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending() :
			Sort.by(sortField).descending();
		
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		return this.userpageRepository.findAll(pageable);
	}

	public boolean processPayment(String cardNumber, String expirationDate, String cvv, double amount) {
        // Implement your payment processing logic here.
        // This is a simplified example; in a real application, you would use a payment gateway.
        if (isValidPayment(cardNumber, expirationDate, cvv, amount)) {
            // Process the payment and return true if successful.
            return true;
        }
        return false;
    }

    private boolean isValidPayment(String cardNumber, String expirationDate, String cvv, double amount) {
        // Validate payment information here.
        // This is a simplified example; perform real validation.
        return !cardNumber.isEmpty() && !expirationDate.isEmpty() && !cvv.isEmpty() && amount > 0;
    }
}
