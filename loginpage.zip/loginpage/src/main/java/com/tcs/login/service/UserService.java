package com.tcs.login.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.tcs.login.model.User;
import com.tcs.login.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
