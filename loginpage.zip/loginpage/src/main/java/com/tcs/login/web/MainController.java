package com.tcs.login.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.tcs.login.model.User;
import com.tcs.login.repository.UserRepository;

@Controller
public class MainController {
	
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("/")
	public String home() {
	    User user = userRepository.findByEmail("abc@gmail.com");
	    if (user != null && user.getEmail().equals("abc@gmail.com")) {
	        return "redirect:http://localhost:8082/";
	    } else if (user != null && user.getEmail().equals("admin@gmail.com")){
	        return "redirect:http://localhost:8081/"; 
	    }
		return "";
	}

}
